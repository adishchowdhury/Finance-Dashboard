import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Transaction, Role } from '../types';

interface FinanceState {
  transactions: Transaction[];
  role: Role;
  setRole: (role: Role) => void;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
}

const initialTransactions: Transaction[] = [
  { id: '1', date: '2024-03-01T10:00:00Z', amount: 5000, category: 'Salary', type: 'income', description: 'Monthly Salary' },
  { id: '2', date: '2024-03-02T14:30:00Z', amount: 1500, category: 'Rent', type: 'expense', description: 'Apartment Rent' },
  { id: '3', date: '2024-03-05T09:15:00Z', amount: 200, category: 'Groceries', type: 'expense', description: 'Supermarket' },
  { id: '4', date: '2024-03-10T18:45:00Z', amount: 120, category: 'Utilities', type: 'expense', description: 'Electricity Bill' },
  { id: '5', date: '2024-03-15T12:00:00Z', amount: 300, category: 'Entertainment', type: 'expense', description: 'Concert Tickets' },
  { id: '6', date: '2024-03-20T08:00:00Z', amount: 50, category: 'Transport', type: 'expense', description: 'Gas' },
  { id: '7', date: '2024-03-25T16:20:00Z', amount: 800, category: 'Freelance', type: 'income', description: 'Web Design Project' },
  { id: '8', date: '2024-03-28T19:10:00Z', amount: 150, category: 'Dining', type: 'expense', description: 'Dinner with friends' },
];

export const useFinanceStore = create<FinanceState>()(
  persist(
    (set) => ({
      transactions: initialTransactions,
      role: 'admin',
      setRole: (role) => set({ role }),
      addTransaction: (transaction) => set((state) => ({
        transactions: [...state.transactions, { ...transaction, id: crypto.randomUUID() }]
      })),
      updateTransaction: (id, updatedTx) => set((state) => ({
        transactions: state.transactions.map((tx) => tx.id === id ? { ...tx, ...updatedTx } : tx)
      })),
      deleteTransaction: (id) => set((state) => ({
        transactions: state.transactions.filter((tx) => tx.id !== id)
      })),
    }),
    {
      name: 'finance-storage',
    }
  )
);
