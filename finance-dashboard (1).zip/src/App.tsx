/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DashboardOverview } from './components/DashboardOverview';
import { TransactionsSection } from './components/TransactionsSection';
import { Insights } from './components/Insights';
import { RoleSwitcher } from './components/RoleSwitcher';
import { ThemeToggle } from './components/ThemeToggle';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { motion } from 'framer-motion';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-50 p-4 md:p-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0"
        >
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Finance Dashboard</h1>
            <p className="text-muted-foreground">Manage your finances and track your spending.</p>
          </div>
          <div className="flex items-center space-x-4">
            <RoleSwitcher />
            <ThemeToggle />
          </div>
        </motion.header>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <DashboardOverview />
              <Insights />
            </TabsContent>
            <TabsContent value="transactions" className="space-y-4">
              <TransactionsSection />
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}



