import React from 'react';
import { useFinanceStore } from '../store/useFinanceStore';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Role } from '../types';
import { ShieldAlertIcon, ShieldCheckIcon } from 'lucide-react';

export function RoleSwitcher() {
  const { role, setRole } = useFinanceStore();

  return (
    <div className="flex items-center space-x-2">
      {role === 'admin' ? (
        <ShieldCheckIcon className="h-4 w-4 text-emerald-500" />
      ) : (
        <ShieldAlertIcon className="h-4 w-4 text-muted-foreground" />
      )}
      <Select value={role} onValueChange={(val) => setRole(val as Role)}>
        <SelectTrigger className="w-[120px] h-8 text-xs">
          <SelectValue placeholder="Select role" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="viewer">Viewer</SelectItem>
          <SelectItem value="admin">Admin</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
