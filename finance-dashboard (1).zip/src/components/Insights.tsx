import React, { useMemo } from 'react';
import { useFinanceStore } from '../store/useFinanceStore';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { format, parseISO, subMonths } from 'date-fns';
import { TrendingUpIcon, TrendingDownIcon, AlertCircleIcon, AwardIcon } from 'lucide-react';

export function Insights() {
  const transactions = useFinanceStore((state) => state.transactions);

  const insights = useMemo(() => {
    if (transactions.length === 0) return null;

    const now = new Date();
    const currentMonthStr = format(now, 'yyyy-MM');
    const lastMonthStr = format(subMonths(now, 1), 'yyyy-MM');

    let currentMonthExpense = 0;
    let lastMonthExpense = 0;
    const categoryTotals: Record<string, number> = {};

    transactions.forEach((tx) => {
      if (tx.type === 'expense') {
        const txMonth = format(parseISO(tx.date), 'yyyy-MM');
        if (txMonth === currentMonthStr) currentMonthExpense += tx.amount;
        if (txMonth === lastMonthStr) lastMonthExpense += tx.amount;

        categoryTotals[tx.category] = (categoryTotals[tx.category] || 0) + tx.amount;
      }
    });

    const highestCategory = Object.entries(categoryTotals).reduce(
      (max, [cat, amount]) => (amount > max.amount ? { cat, amount } : max),
      { cat: 'None', amount: 0 }
    );

    const expenseChange = lastMonthExpense > 0 
      ? ((currentMonthExpense - lastMonthExpense) / lastMonthExpense) * 100 
      : 0;

    return {
      highestCategory,
      currentMonthExpense,
      lastMonthExpense,
      expenseChange,
    };
  }, [transactions]);

  if (!insights) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex h-24 items-center justify-center text-muted-foreground">
            Add some transactions to see insights.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Highest Spending Category</CardTitle>
          <AwardIcon className="h-4 w-4 text-amber-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{insights.highestCategory.cat}</div>
          <p className="text-xs text-muted-foreground">
            ${insights.highestCategory.amount.toLocaleString()} total spent
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Monthly Comparison</CardTitle>
          {insights.expenseChange > 0 ? (
            <TrendingUpIcon className="h-4 w-4 text-rose-500" />
          ) : (
            <TrendingDownIcon className="h-4 w-4 text-emerald-500" />
          )}
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {Math.abs(insights.expenseChange).toFixed(1)}%
          </div>
          <p className="text-xs text-muted-foreground">
            {insights.expenseChange > 0 ? 'more' : 'less'} expenses than last month
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Observation</CardTitle>
          <AlertCircleIcon className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-sm font-medium leading-tight">
            {insights.expenseChange > 20 
              ? "Your spending is significantly higher this month. Consider reviewing your budget."
              : insights.expenseChange < -20 
              ? "Great job! You've significantly reduced your expenses this month."
              : "Your spending is relatively stable compared to last month."}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
